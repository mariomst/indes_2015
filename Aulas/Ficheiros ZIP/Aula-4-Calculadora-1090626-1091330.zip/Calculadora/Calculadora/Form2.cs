﻿using System.Windows.Forms;

namespace Calculadora
{
    public partial class formAbout : Form
    {
        public formAbout()
        {
            InitializeComponent();
        }
    }
}
