﻿namespace Domotica
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lampada1 = new System.Windows.Forms.PictureBox();
            this.alarme1 = new System.Windows.Forms.PictureBox();
            this.lampada2 = new System.Windows.Forms.PictureBox();
            this.alarme2 = new System.Windows.Forms.PictureBox();
            this.alarme3 = new System.Windows.Forms.PictureBox();
            this.lampada3 = new System.Windows.Forms.PictureBox();
            this.alarme4 = new System.Windows.Forms.PictureBox();
            this.lampada4 = new System.Windows.Forms.PictureBox();
            this.lampada5 = new System.Windows.Forms.PictureBox();
            this.alarme5 = new System.Windows.Forms.PictureBox();
            this.temp1 = new System.Windows.Forms.PictureBox();
            this.temp1label = new System.Windows.Forms.Label();
            this.temp2label = new System.Windows.Forms.Label();
            this.temp2 = new System.Windows.Forms.PictureBox();
            this.temp3label = new System.Windows.Forms.Label();
            this.temp3 = new System.Windows.Forms.PictureBox();
            this.fogao1 = new System.Windows.Forms.PictureBox();
            this.fogao2 = new System.Windows.Forms.PictureBox();
            this.fogao3 = new System.Windows.Forms.PictureBox();
            this.fogao4 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.lampada1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.alarme1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lampada2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.alarme2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.alarme3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lampada3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.alarme4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lampada4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lampada5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.alarme5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.temp1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.temp2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.temp3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fogao1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fogao2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fogao3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fogao4)).BeginInit();
            this.SuspendLayout();
            // 
            // lampada1
            // 
            this.lampada1.BackgroundImage = global::Domotica.Properties.Resources.LUZ_OFF;
            this.lampada1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.lampada1.Location = new System.Drawing.Point(124, 188);
            this.lampada1.Name = "lampada1";
            this.lampada1.Size = new System.Drawing.Size(86, 79);
            this.lampada1.TabIndex = 0;
            this.lampada1.TabStop = false;
            this.lampada1.Click += new System.EventHandler(this.lampada1_Click);
            // 
            // alarme1
            // 
            this.alarme1.BackgroundImage = global::Domotica.Properties.Resources.alarmeoff;
            this.alarme1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.alarme1.Location = new System.Drawing.Point(30, 231);
            this.alarme1.Name = "alarme1";
            this.alarme1.Size = new System.Drawing.Size(72, 36);
            this.alarme1.TabIndex = 1;
            this.alarme1.TabStop = false;
            this.alarme1.Click += new System.EventHandler(this.alarme1_Click);
            // 
            // lampada2
            // 
            this.lampada2.BackgroundImage = global::Domotica.Properties.Resources.LUZ_OFF;
            this.lampada2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.lampada2.Location = new System.Drawing.Point(415, 188);
            this.lampada2.Name = "lampada2";
            this.lampada2.Size = new System.Drawing.Size(90, 79);
            this.lampada2.TabIndex = 2;
            this.lampada2.TabStop = false;
            this.lampada2.Click += new System.EventHandler(this.lampada2_Click);
            // 
            // alarme2
            // 
            this.alarme2.BackgroundImage = global::Domotica.Properties.Resources.alarmeoff;
            this.alarme2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.alarme2.Location = new System.Drawing.Point(333, 231);
            this.alarme2.Name = "alarme2";
            this.alarme2.Size = new System.Drawing.Size(72, 36);
            this.alarme2.TabIndex = 3;
            this.alarme2.TabStop = false;
            this.alarme2.Click += new System.EventHandler(this.alarme2_Click);
            // 
            // alarme3
            // 
            this.alarme3.BackgroundImage = global::Domotica.Properties.Resources.alarmeoff;
            this.alarme3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.alarme3.Location = new System.Drawing.Point(634, 231);
            this.alarme3.Name = "alarme3";
            this.alarme3.Size = new System.Drawing.Size(72, 36);
            this.alarme3.TabIndex = 4;
            this.alarme3.TabStop = false;
            this.alarme3.Click += new System.EventHandler(this.alarme3_Click);
            // 
            // lampada3
            // 
            this.lampada3.BackgroundImage = global::Domotica.Properties.Resources.LUZ_OFF;
            this.lampada3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.lampada3.Location = new System.Drawing.Point(712, 208);
            this.lampada3.Name = "lampada3";
            this.lampada3.Size = new System.Drawing.Size(90, 81);
            this.lampada3.TabIndex = 5;
            this.lampada3.TabStop = false;
            this.lampada3.Click += new System.EventHandler(this.lampada3_Click);
            // 
            // alarme4
            // 
            this.alarme4.BackgroundImage = global::Domotica.Properties.Resources.alarmeoff;
            this.alarme4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.alarme4.Location = new System.Drawing.Point(251, 557);
            this.alarme4.Name = "alarme4";
            this.alarme4.Size = new System.Drawing.Size(72, 36);
            this.alarme4.TabIndex = 6;
            this.alarme4.TabStop = false;
            this.alarme4.Click += new System.EventHandler(this.alarme4_Click);
            // 
            // lampada4
            // 
            this.lampada4.BackgroundImage = global::Domotica.Properties.Resources.LUZ_OFF;
            this.lampada4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.lampada4.Location = new System.Drawing.Point(373, 492);
            this.lampada4.Name = "lampada4";
            this.lampada4.Size = new System.Drawing.Size(90, 76);
            this.lampada4.TabIndex = 7;
            this.lampada4.TabStop = false;
            this.lampada4.Click += new System.EventHandler(this.lampada4_Click);
            // 
            // lampada5
            // 
            this.lampada5.BackgroundImage = global::Domotica.Properties.Resources.LUZ_OFF;
            this.lampada5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.lampada5.Location = new System.Drawing.Point(623, 492);
            this.lampada5.Name = "lampada5";
            this.lampada5.Size = new System.Drawing.Size(83, 76);
            this.lampada5.TabIndex = 8;
            this.lampada5.TabStop = false;
            this.lampada5.Click += new System.EventHandler(this.lampada5_Click);
            // 
            // alarme5
            // 
            this.alarme5.BackgroundImage = global::Domotica.Properties.Resources.alarmeoff;
            this.alarme5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.alarme5.Location = new System.Drawing.Point(813, 557);
            this.alarme5.Name = "alarme5";
            this.alarme5.Size = new System.Drawing.Size(72, 36);
            this.alarme5.TabIndex = 9;
            this.alarme5.TabStop = false;
            this.alarme5.Click += new System.EventHandler(this.alarme5_Click);
            // 
            // temp1
            // 
            this.temp1.BackgroundImage = global::Domotica.Properties.Resources.tempcold;
            this.temp1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.temp1.Location = new System.Drawing.Point(520, 252);
            this.temp1.Name = "temp1";
            this.temp1.Size = new System.Drawing.Size(66, 58);
            this.temp1.TabIndex = 10;
            this.temp1.TabStop = false;
            this.temp1.Click += new System.EventHandler(this.temp1_Click);
            // 
            // temp1label
            // 
            this.temp1label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.temp1label.ForeColor = System.Drawing.Color.Red;
            this.temp1label.Location = new System.Drawing.Point(529, 229);
            this.temp1label.Name = "temp1label";
            this.temp1label.Size = new System.Drawing.Size(57, 23);
            this.temp1label.TabIndex = 11;
            this.temp1label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // temp2label
            // 
            this.temp2label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.temp2label.ForeColor = System.Drawing.Color.Red;
            this.temp2label.Location = new System.Drawing.Point(840, 229);
            this.temp2label.Name = "temp2label";
            this.temp2label.Size = new System.Drawing.Size(57, 23);
            this.temp2label.TabIndex = 13;
            this.temp2label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // temp2
            // 
            this.temp2.BackgroundImage = global::Domotica.Properties.Resources.tempcold;
            this.temp2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.temp2.Location = new System.Drawing.Point(831, 252);
            this.temp2.Name = "temp2";
            this.temp2.Size = new System.Drawing.Size(66, 58);
            this.temp2.TabIndex = 12;
            this.temp2.TabStop = false;
            this.temp2.Click += new System.EventHandler(this.temp2_Click);
            // 
            // temp3label
            // 
            this.temp3label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.temp3label.ForeColor = System.Drawing.Color.Red;
            this.temp3label.Location = new System.Drawing.Point(514, 512);
            this.temp3label.Name = "temp3label";
            this.temp3label.Size = new System.Drawing.Size(57, 23);
            this.temp3label.TabIndex = 15;
            this.temp3label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // temp3
            // 
            this.temp3.BackgroundImage = global::Domotica.Properties.Resources.tempcold;
            this.temp3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.temp3.Location = new System.Drawing.Point(505, 535);
            this.temp3.Name = "temp3";
            this.temp3.Size = new System.Drawing.Size(66, 58);
            this.temp3.TabIndex = 14;
            this.temp3.TabStop = false;
            this.temp3.Click += new System.EventHandler(this.temp3_Click);
            // 
            // fogao1
            // 
            this.fogao1.BackgroundImage = global::Domotica.Properties.Resources.fogao0;
            this.fogao1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.fogao1.Location = new System.Drawing.Point(30, 420);
            this.fogao1.Name = "fogao1";
            this.fogao1.Size = new System.Drawing.Size(61, 58);
            this.fogao1.TabIndex = 16;
            this.fogao1.TabStop = false;
            this.fogao1.Click += new System.EventHandler(this.fogao1_Click);
            // 
            // fogao2
            // 
            this.fogao2.BackgroundImage = global::Domotica.Properties.Resources.fogao0;
            this.fogao2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.fogao2.Location = new System.Drawing.Point(97, 420);
            this.fogao2.Name = "fogao2";
            this.fogao2.Size = new System.Drawing.Size(61, 58);
            this.fogao2.TabIndex = 17;
            this.fogao2.TabStop = false;
            this.fogao2.Click += new System.EventHandler(this.fogao2_Click);
            // 
            // fogao3
            // 
            this.fogao3.BackgroundImage = global::Domotica.Properties.Resources.fogao0;
            this.fogao3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.fogao3.Location = new System.Drawing.Point(30, 477);
            this.fogao3.Name = "fogao3";
            this.fogao3.Size = new System.Drawing.Size(61, 58);
            this.fogao3.TabIndex = 18;
            this.fogao3.TabStop = false;
            this.fogao3.Click += new System.EventHandler(this.fogao3_Click);
            // 
            // fogao4
            // 
            this.fogao4.BackgroundImage = global::Domotica.Properties.Resources.fogao0;
            this.fogao4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.fogao4.Location = new System.Drawing.Point(97, 477);
            this.fogao4.Name = "fogao4";
            this.fogao4.Size = new System.Drawing.Size(61, 58);
            this.fogao4.TabIndex = 19;
            this.fogao4.TabStop = false;
            this.fogao4.Click += new System.EventHandler(this.fogao4_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Domotica.Properties.Resources.background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(909, 619);
            this.Controls.Add(this.fogao4);
            this.Controls.Add(this.fogao3);
            this.Controls.Add(this.fogao2);
            this.Controls.Add(this.fogao1);
            this.Controls.Add(this.temp3label);
            this.Controls.Add(this.temp3);
            this.Controls.Add(this.temp2label);
            this.Controls.Add(this.temp2);
            this.Controls.Add(this.temp1label);
            this.Controls.Add(this.temp1);
            this.Controls.Add(this.alarme5);
            this.Controls.Add(this.lampada5);
            this.Controls.Add(this.lampada4);
            this.Controls.Add(this.alarme4);
            this.Controls.Add(this.lampada3);
            this.Controls.Add(this.alarme3);
            this.Controls.Add(this.alarme2);
            this.Controls.Add(this.lampada2);
            this.Controls.Add(this.alarme1);
            this.Controls.Add(this.lampada1);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Domotica";
            ((System.ComponentModel.ISupportInitialize)(this.lampada1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.alarme1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lampada2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.alarme2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.alarme3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lampada3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.alarme4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lampada4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lampada5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.alarme5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.temp1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.temp2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.temp3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fogao1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fogao2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fogao3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fogao4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox lampada1;
        private System.Windows.Forms.PictureBox alarme1;
        private System.Windows.Forms.PictureBox lampada2;
        private System.Windows.Forms.PictureBox alarme2;
        private System.Windows.Forms.PictureBox alarme3;
        private System.Windows.Forms.PictureBox lampada3;
        private System.Windows.Forms.PictureBox alarme4;
        private System.Windows.Forms.PictureBox lampada4;
        private System.Windows.Forms.PictureBox lampada5;
        private System.Windows.Forms.PictureBox alarme5;
        private System.Windows.Forms.PictureBox temp1;
        private System.Windows.Forms.Label temp1label;
        private System.Windows.Forms.Label temp2label;
        private System.Windows.Forms.PictureBox temp2;
        private System.Windows.Forms.Label temp3label;
        private System.Windows.Forms.PictureBox temp3;
        private System.Windows.Forms.PictureBox fogao1;
        private System.Windows.Forms.PictureBox fogao2;
        private System.Windows.Forms.PictureBox fogao3;
        private System.Windows.Forms.PictureBox fogao4;
    }
}

