package org.ofbiz.battleships.services;

//Bibliotecas necessarias:
import java.util.Map;

//Bibliotecas OFBIZ necessarias:
import org.ofbiz.entity.Delegator;
import org.ofbiz.entity.GenericEntityException;
import org.ofbiz.entity.GenericValue;
import org.ofbiz.service.DispatchContext;
import org.ofbiz.service.ServiceUtil;

public class battleshipsServices 
{
	//Funcao para gravar a pontuacao do jogo Battleships
	public static Map<String, Object> addScore(DispatchContext dctx, Map<String, Object> context) throws GenericEntityException
	{
		Map<String, Object> result = ServiceUtil.returnSuccess();
		
		Delegator delegator = dctx.getDelegator();
		GenericValue score  = delegator.makeValue("Score");
		
		//Obter o proximo ID
		String scoreId		= delegator.getNextSeqId("Score");
		
		//Variaveis a serem recebidas e inseridas na base de dados
		String username     = (String)context.get("username");
		String hits         = (String)context.get("hits");		
		String misses       = (String)context.get("misses");
		String hitsPercet   = (String)context.get("hitsPercet");
		String winner       = (String)context.get("winner");
				
		score.set("scoreId", scoreId);
		score.set("username", username);
		score.set("hits", hits);
		score.set("misses", misses);
		score.set("hitsPercet", hitsPercet);
		score.set("winner", winner);
						
		try
		{
			delegator.create(score);
		}
		catch (GenericEntityException error)
		{
			System.out.println("Error: Fail to insert score!");
			return ServiceUtil.returnError(error.getMessage());
		}
		
		result.put("scoreId", scoreId);				
		return result;
	}	
}
