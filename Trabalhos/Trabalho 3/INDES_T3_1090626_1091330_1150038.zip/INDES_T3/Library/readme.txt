Jon Skeet's Miscellaneous Utility Library
-----------------------------------------

You can always find the most recent version of this library at
http://www.pobox.com/~skeet/csharp/miscutil

Documentation and history is also available at the above website.
