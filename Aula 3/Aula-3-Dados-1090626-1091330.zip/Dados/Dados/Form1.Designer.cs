﻿namespace Dados
{
    partial class formDados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formDados));
            this.dice1img = new System.Windows.Forms.PictureBox();
            this.dice2img = new System.Windows.Forms.PictureBox();
            this.dice3img = new System.Windows.Forms.PictureBox();
            this.dice4img = new System.Windows.Forms.PictureBox();
            this.dice5img = new System.Windows.Forms.PictureBox();
            this.dice6img = new System.Windows.Forms.PictureBox();
            this.dice7img = new System.Windows.Forms.PictureBox();
            this.dice8img = new System.Windows.Forms.PictureBox();
            this.dice9img = new System.Windows.Forms.PictureBox();
            this.dice10img = new System.Windows.Forms.PictureBox();
            this.dice11img = new System.Windows.Forms.PictureBox();
            this.dice12img = new System.Windows.Forms.PictureBox();
            this.roll = new System.Windows.Forms.Button();
            this.statsView = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dice1img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice2img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice3img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice4img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice5img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice6img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice7img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice8img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice9img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice10img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice11img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice12img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.statsView)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dice1img
            // 
            this.dice1img.BackColor = System.Drawing.Color.Transparent;
            this.dice1img.BackgroundImage = global::Dados.Properties.Resources.dice_1;
            this.dice1img.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.dice1img.Location = new System.Drawing.Point(12, 51);
            this.dice1img.Name = "dice1img";
            this.dice1img.Size = new System.Drawing.Size(70, 70);
            this.dice1img.TabIndex = 1;
            this.dice1img.TabStop = false;
            // 
            // dice2img
            // 
            this.dice2img.BackColor = System.Drawing.Color.Transparent;
            this.dice2img.BackgroundImage = global::Dados.Properties.Resources.dice_1;
            this.dice2img.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.dice2img.Location = new System.Drawing.Point(104, 51);
            this.dice2img.Name = "dice2img";
            this.dice2img.Size = new System.Drawing.Size(70, 70);
            this.dice2img.TabIndex = 2;
            this.dice2img.TabStop = false;
            // 
            // dice3img
            // 
            this.dice3img.BackColor = System.Drawing.Color.Transparent;
            this.dice3img.BackgroundImage = global::Dados.Properties.Resources.dice_1;
            this.dice3img.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.dice3img.Location = new System.Drawing.Point(198, 51);
            this.dice3img.Name = "dice3img";
            this.dice3img.Size = new System.Drawing.Size(70, 70);
            this.dice3img.TabIndex = 3;
            this.dice3img.TabStop = false;
            // 
            // dice4img
            // 
            this.dice4img.BackColor = System.Drawing.Color.Transparent;
            this.dice4img.BackgroundImage = global::Dados.Properties.Resources.dice_1;
            this.dice4img.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.dice4img.Location = new System.Drawing.Point(292, 51);
            this.dice4img.Name = "dice4img";
            this.dice4img.Size = new System.Drawing.Size(70, 70);
            this.dice4img.TabIndex = 4;
            this.dice4img.TabStop = false;
            // 
            // dice5img
            // 
            this.dice5img.BackColor = System.Drawing.Color.Transparent;
            this.dice5img.BackgroundImage = global::Dados.Properties.Resources.dice_1;
            this.dice5img.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.dice5img.Location = new System.Drawing.Point(386, 51);
            this.dice5img.Name = "dice5img";
            this.dice5img.Size = new System.Drawing.Size(70, 70);
            this.dice5img.TabIndex = 5;
            this.dice5img.TabStop = false;
            // 
            // dice6img
            // 
            this.dice6img.BackColor = System.Drawing.Color.Transparent;
            this.dice6img.BackgroundImage = global::Dados.Properties.Resources.dice_1;
            this.dice6img.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.dice6img.Location = new System.Drawing.Point(482, 51);
            this.dice6img.Name = "dice6img";
            this.dice6img.Size = new System.Drawing.Size(70, 70);
            this.dice6img.TabIndex = 6;
            this.dice6img.TabStop = false;
            // 
            // dice7img
            // 
            this.dice7img.BackColor = System.Drawing.Color.Transparent;
            this.dice7img.BackgroundImage = global::Dados.Properties.Resources.dice_1;
            this.dice7img.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.dice7img.Location = new System.Drawing.Point(12, 139);
            this.dice7img.Name = "dice7img";
            this.dice7img.Size = new System.Drawing.Size(70, 70);
            this.dice7img.TabIndex = 7;
            this.dice7img.TabStop = false;
            // 
            // dice8img
            // 
            this.dice8img.BackColor = System.Drawing.Color.Transparent;
            this.dice8img.BackgroundImage = global::Dados.Properties.Resources.dice_1;
            this.dice8img.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.dice8img.Location = new System.Drawing.Point(104, 139);
            this.dice8img.Name = "dice8img";
            this.dice8img.Size = new System.Drawing.Size(70, 70);
            this.dice8img.TabIndex = 8;
            this.dice8img.TabStop = false;
            // 
            // dice9img
            // 
            this.dice9img.BackColor = System.Drawing.Color.Transparent;
            this.dice9img.BackgroundImage = global::Dados.Properties.Resources.dice_1;
            this.dice9img.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.dice9img.Location = new System.Drawing.Point(198, 139);
            this.dice9img.Name = "dice9img";
            this.dice9img.Size = new System.Drawing.Size(70, 70);
            this.dice9img.TabIndex = 9;
            this.dice9img.TabStop = false;
            // 
            // dice10img
            // 
            this.dice10img.BackColor = System.Drawing.Color.Transparent;
            this.dice10img.BackgroundImage = global::Dados.Properties.Resources.dice_1;
            this.dice10img.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.dice10img.Location = new System.Drawing.Point(292, 139);
            this.dice10img.Name = "dice10img";
            this.dice10img.Size = new System.Drawing.Size(70, 70);
            this.dice10img.TabIndex = 10;
            this.dice10img.TabStop = false;
            // 
            // dice11img
            // 
            this.dice11img.BackColor = System.Drawing.Color.Transparent;
            this.dice11img.BackgroundImage = global::Dados.Properties.Resources.dice_1;
            this.dice11img.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.dice11img.Location = new System.Drawing.Point(386, 139);
            this.dice11img.Name = "dice11img";
            this.dice11img.Size = new System.Drawing.Size(70, 70);
            this.dice11img.TabIndex = 11;
            this.dice11img.TabStop = false;
            // 
            // dice12img
            // 
            this.dice12img.BackColor = System.Drawing.Color.Transparent;
            this.dice12img.BackgroundImage = global::Dados.Properties.Resources.dice_1;
            this.dice12img.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.dice12img.Location = new System.Drawing.Point(482, 139);
            this.dice12img.Name = "dice12img";
            this.dice12img.Size = new System.Drawing.Size(70, 70);
            this.dice12img.TabIndex = 12;
            this.dice12img.TabStop = false;
            // 
            // roll
            // 
            this.roll.Location = new System.Drawing.Point(198, 231);
            this.roll.Name = "roll";
            this.roll.Size = new System.Drawing.Size(164, 23);
            this.roll.TabIndex = 13;
            this.roll.Text = "Roll";
            this.roll.UseVisualStyleBackColor = true;
            this.roll.Click += new System.EventHandler(this.roll_Click);
            // 
            // statsView
            // 
            this.statsView.AllowUserToAddRows = false;
            this.statsView.AllowUserToDeleteRows = false;
            this.statsView.AllowUserToResizeColumns = false;
            this.statsView.AllowUserToResizeRows = false;
            this.statsView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.statsView.BackgroundColor = System.Drawing.SystemColors.Window;
            this.statsView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.statsView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.statsView.Cursor = System.Windows.Forms.Cursors.Default;
            this.statsView.Location = new System.Drawing.Point(12, 269);
            this.statsView.Name = "statsView";
            this.statsView.ReadOnly = true;
            this.statsView.RowTemplate.ReadOnly = true;
            this.statsView.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.statsView.ShowCellErrors = false;
            this.statsView.ShowCellToolTips = false;
            this.statsView.ShowEditingIcon = false;
            this.statsView.ShowRowErrors = false;
            this.statsView.Size = new System.Drawing.Size(540, 157);
            this.statsView.TabIndex = 14;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.White;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(568, 24);
            this.menuStrip1.TabIndex = 15;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutMenuItem,
            this.toolStripSeparator1,
            this.exitMenuItem});
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.menuToolStripMenuItem.Text = "Menu";
            // 
            // aboutMenuItem
            // 
            this.aboutMenuItem.Name = "aboutMenuItem";
            this.aboutMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.aboutMenuItem.Size = new System.Drawing.Size(149, 22);
            this.aboutMenuItem.Text = "About";
            this.aboutMenuItem.Click += new System.EventHandler(this.aboutMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(146, 6);
            // 
            // exitMenuItem
            // 
            this.exitMenuItem.Name = "exitMenuItem";
            this.exitMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E)));
            this.exitMenuItem.Size = new System.Drawing.Size(149, 22);
            this.exitMenuItem.Text = "Exit";
            this.exitMenuItem.Click += new System.EventHandler(this.exitMenuItem_Click);
            // 
            // formDados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Dados.Properties.Resources.background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(568, 448);
            this.Controls.Add(this.statsView);
            this.Controls.Add(this.roll);
            this.Controls.Add(this.dice12img);
            this.Controls.Add(this.dice11img);
            this.Controls.Add(this.dice10img);
            this.Controls.Add(this.dice9img);
            this.Controls.Add(this.dice8img);
            this.Controls.Add(this.dice7img);
            this.Controls.Add(this.dice6img);
            this.Controls.Add(this.dice5img);
            this.Controls.Add(this.dice4img);
            this.Controls.Add(this.dice3img);
            this.Controls.Add(this.dice2img);
            this.Controls.Add(this.dice1img);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "formDados";
            this.Text = "Dados V2.0";
            ((System.ComponentModel.ISupportInitialize)(this.dice1img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice2img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice3img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice4img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice5img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice6img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice7img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice8img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice9img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice10img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice11img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice12img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.statsView)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox dice1img;
        private System.Windows.Forms.PictureBox dice2img;
        private System.Windows.Forms.PictureBox dice3img;
        private System.Windows.Forms.PictureBox dice4img;
        private System.Windows.Forms.PictureBox dice5img;
        private System.Windows.Forms.PictureBox dice6img;
        private System.Windows.Forms.PictureBox dice7img;
        private System.Windows.Forms.PictureBox dice8img;
        private System.Windows.Forms.PictureBox dice9img;
        private System.Windows.Forms.PictureBox dice10img;
        private System.Windows.Forms.PictureBox dice11img;
        private System.Windows.Forms.PictureBox dice12img;
        private System.Windows.Forms.Button roll;
        private System.Windows.Forms.DataGridView statsView;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitMenuItem;
    }
}

